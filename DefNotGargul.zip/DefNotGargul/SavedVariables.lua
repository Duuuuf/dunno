-- SavedVariables.lua
GargulLiteDB = {
    profile = {
        window = {
            width = 300,
            height = 150,
            alpha = 0.6,
        },
        items = {},          -- stores the items tracked in the addon
        softRes = {},        -- stores parsed softres.it data
    }
}