-- UI/ItemRow.lua
local AddonName, GL = ...
GL.UI = GL.UI or {}
local UI = GL.UI

function UI.CreateItemRow(parent, entry, index)
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(parent:GetWidth()-10, 20)

    -- Item text
    local text = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    text:SetPoint("LEFT", 5, 0)
    text:SetText(entry.link or entry.id or "item")
    row.text = text

    -- Start Roll button
    local startBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    startBtn:SetSize(50, 18)
    startBtn:SetPoint("RIGHT", row, -5, 0)
    startBtn:SetText("Roll")
    startBtn:SetScript("OnClick", function()
        GL.StartRollForIndex(index, 30)
    end)

    -- Announce button
    local annBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    annBtn:SetSize(60, 18)
    annBtn:SetPoint("RIGHT", startBtn, "LEFT", -5, 0)
    annBtn:SetText("Announce")
    annBtn:SetScript("OnClick", function()
        GL.AnnounceItem(index)
    end)

    -- Discard button
    local discardBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    discardBtn:SetSize(50, 18)
    discardBtn:SetPoint("RIGHT", annBtn, "LEFT", -5, 0)
    discardBtn:SetText("Discard")
    discardBtn:SetScript("OnClick", function()
        GL.DiscardItem(index)
    end)

    return row
end