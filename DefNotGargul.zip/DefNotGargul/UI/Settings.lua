-- UI/Settings.lua
local AddonName, GL = ...
GL.UI = GL.UI or {}
local UI = GL.UI

function UI.ApplySettings()
    local frame = UI.frame
    if not frame then return end

    local w = GL.db.window.width or 300
    local h = GL.db.window.height or 150
    local a = GL.db.window.alpha or 0.6

    frame:SetSize(w, h)
    frame:SetBackdropColor(0,0,0,a)
end

function UI.OpenSettingsPanel()
    -- Placeholder for an actual settings panel
    GL:Print("Settings panel is under construction")
end

-- Example usage: apply settings on login
UI.ApplySettings()