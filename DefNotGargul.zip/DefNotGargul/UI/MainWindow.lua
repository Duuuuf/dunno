-- UI/MainWindow.lua
local AddonName, GL = ...
GL.UI = GL.UI or {}
local UI = GL.UI

-- Create main frame
local frame = CreateFrame("Frame", AddonName.."Frame", UIParent, "BackdropTemplate")
frame:SetSize(GL.db.window.width, GL.db.window.height)
frame:SetPoint("CENTER")
frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", 
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = { left = 5, right = 5, top = 5, bottom = 5 }
})
frame:SetBackdropColor(0,0,0,GL.db.window.alpha)
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)

UI.frame = frame

-- Scroll child frame for items
local scrollFrame = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", 10, -10)
scrollFrame:SetPoint("BOTTOMRIGHT", -30, 10)

local content = CreateFrame("Frame", nil, scrollFrame)
content:SetSize(frame:GetWidth()-20, frame:GetHeight()-20)
scrollFrame:SetScrollChild(content)
UI.content = content

-- Placeholder function to refresh item list
function GL.RefreshUI()
    local y = -5
    for i, entry in ipairs(GL.Items or {}) do
        local row = UI.Rows and UI.Rows[i] or CreateFrame("Frame", nil, content)
        row:SetSize(content:GetWidth()-10, 20)
        row:SetPoint("TOPLEFT", 5, y)

        if not row.text then
            row.text = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            row.text:SetPoint("LEFT", 5, 0)
        end
        row.text:SetText(entry.link or entry.id or "item")

        y = y - 25
    end
end

-- Initialize UI
GL.RefreshUI()