-- Utils/Table.lua
local AddonName, GL = ...
GL.Utils = GL.Utils or {}
GL.Utils.Table = GL.Utils.Table or {}
local T = GL.Utils.Table


function T.copy(tbl)
    local copy = {}
    for k,v in pairs(tbl) do
        copy[k] = v
    end
    return copy
end

function T.contains(tbl, value)
    for _,v in pairs(tbl) do
        if v == value then return true end 
    end
    return false
end