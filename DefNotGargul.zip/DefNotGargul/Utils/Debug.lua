-- Utils/Debug.lua
local AddonName, GL = ...
GL.Utils = GL.Utils or {}
GL.Utils.Debug = GL.Utils.Debug or {}
local D = GL.Utils.Debug

function D.Print(...)
    local t = {}
    for i=1, select("#", ...) do
        table.insert(t, tostring(select(i, ...)))
    end
    DEFAULT_CHAT_FRAME:AddMessage("|cff00ffff[Debug]|r " .. table.concat(t, ", "))
end
