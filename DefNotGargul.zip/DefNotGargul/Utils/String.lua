-- Utils/String.lua
local AddonName, GL = ...
GL.Utils = GL.Utils or {}
GL.Utils.String = GL.Utils.String or {}
local S = GL.Utils.String

-- Trim leading and trailing whitespace
function S.trim(s)
    if not s then return "" end
    return s:gsub("^%s+", ""):gsub("%s+$", "")
end

-- Split string by separator
function S.split(s, sep)
    local t = {}
    for str in string.gmatch(s, "[^"..sep.."]+") do
        table.insert(t, str)
    end
    return t
end