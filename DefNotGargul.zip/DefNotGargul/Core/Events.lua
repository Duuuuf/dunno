-- Core/Events.lua
local AddonName, GL = ...
local Events = {}
GL.Events = Events


local frame = CreateFrame("Frame")
Events.frame = frame


-- Event registry
local handlers = {}


function Events:Register(event, func)
if not handlers[event] then
handlers[event] = {}
frame:RegisterEvent(event)
end
table.insert(handlers[event], func)
end


frame:SetScript("OnEvent", function(_, event, ...)
if not handlers[event] then return end
for _, func in ipairs(handlers[event]) do
func(...)
end
end)


-- We hook modified item clicks so shift-click works
hooksecurefunc("HandleModifiedItemClick", function(link)
if IsShiftKeyDown() and link and GL.OnShiftClickItem then
GL.OnShiftClickItem(link)
end
end)


-- LOOT_OPENED handler (detect items from bosses)
local function OnLootOpened(autoLoot)
local numItems = GetNumLootItems()
if numItems == 0 then return end


for slot = 1, numItems do
local link = GetLootSlotLink(slot)
if link then
if GL.OnLootReceived then
GL.OnLootReceived(link)
end
end
end
end


Events:Register("LOOT_OPENED", OnLootOpened)


-- PLAYER_LOGIN event → initialize addon
Events:Register("PLAYER_LOGIN", function()
GL:Initialize()
end)