-- Core/Rolls.lua
local AddonName, GL = ...
GL.Rolls = GL.Rolls or {}

GL.Rolls.current = GL.Rolls.current or nil

local function EndRoll(reason)
    local current = GL.Rolls.current
    if not current then return end

    local best, winner = -1, nil
    for player, roll in pairs(current.rolls) do
        if roll > best then
            best = roll
            winner = player
        end
    end

    local msg
    if winner then
        msg = string.format("Roll ended for %s — winner: %s (%d)", current.link or current.name or "item", winner, best)
    else
        msg = "Roll ended — no rolls recorded"
    end

    if current.announceToRaid then
        SendChatMessage(msg, "RAID_WARNING")
    end

    GL.Rolls.current = nil
    if GL.RefreshUI then GL.RefreshUI() end
end

local function StartRoll(entry, duration)
    duration = duration or 30
    local sr = GL.SoftRes.GetSRForItemId and GL.SoftRes.GetSRForItemId(entry.id)
    local srText = sr and (#sr>0 and (" SR: " .. table.concat(sr, ", ")) or "") or ""

    GL.Rolls.current = {
        link = entry.link,
        id = entry.id,
        endsAt = time() + duration,
        rolls = {},
        announceToRaid = true,
    }

    local announceText = string.format("Rolling started for %s. %d seconds.%s", entry.link or entry.name or "item", duration, srText)
    SendChatMessage(announceText, "RAID_WARNING")

    C_Timer.After(duration, function() EndRoll("timeout") end)
    if GL.RefreshUI then GL.RefreshUI() end
end

-- Parse /roll system messages (English only, adjust for private server locale if needed)
function GL.OnChatSystem(msg)
    local current = GL.Rolls.current
    if not current then return end

    local player, roll = msg:match("^(.-) rolls (%d+)")
    if player and roll then
        current.rolls[player] = tonumber(roll)
        if GL.RefreshUI then GL.RefreshUI() end
    end
end

-- Public API
function GL.StartRollForIndex(index, duration)
    local entry = GL.Items[index]
    if entry then StartRoll(entry, duration) end
end

function GL.EndRollNow()
    EndRoll("manual")
end

function GL.AnnounceItem(index)
    local entry = GL.Items[index]
    if not entry then return end
    local sr = GL.SoftRes.GetSRForItemId and GL.SoftRes.GetSRForItemId(entry.id)
    local srText = sr and (#sr>0 and (" SR: " .. table.concat(sr, ", ")) or "") or ""
    local text = string.format("Item: %s%s", entry.link or entry.name or "item", srText)
    SendChatMessage(text, "RAID_WARNING")
end

function GL.DiscardItem(index)
    table.remove(GL.Items, index)
    if GL.RefreshUI then GL.RefreshUI() end
end