-- Core/Init.lua
local AddonName, GL = ...
_G[AddonName] = GL


GL.VERSION = "1.0"


local function InitDB()
if not GargulLiteDB then
GargulLiteDB = { profile = {} }
end


GL.db = GargulLiteDB.profile
GL.db.window = GL.db.window or {
width = 300,
height = 150,
alpha = 0.6,
}
end


function GL:Print(msg)
DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00[GargulLite]|r " .. tostring(msg))
end


function GL:Initialize()
InitDB()
GL.Items = GL.Items or {}
GL.SoftResTable = GL.SoftResTable or {}
GL.Rolls = GL.Rolls or {}


if GL.OnInitialize then
GL.OnInitialize()
end
end


_G.GargulLite = GL