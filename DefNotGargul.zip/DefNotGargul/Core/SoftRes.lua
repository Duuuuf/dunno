-- Core/SoftRes.lua
local AddonName, GL = ...
GL.SoftRes = GL.SoftRes or {}
local SR = GL.SoftRes

-- Parse a softres.it export string
function SR.ParseSoftResExport(exportString)
    if not exportString or exportString == "" then return end

    GL.SoftResTable = GL.SoftResTable or {}
    local byItem = {}

    for line in exportString:gmatch("[^\r\n]+") do
        -- Look for itemlink first
        local itemlink = line:match("(|c.-|Hitem:.-|h%[.-%]|h|r)")
        if itemlink then
            local id = itemlink:match("|Hitem:(%d+):")
            -- Look for player names after '-' or inside parentheses
            local player = line:match("%-%s*([^%-%(]+)%s*%(") or line:match("%-%s*(.+)$")
            if id and player then
                byItem[id] = byItem[id] or {}
                table.insert(byItem[id], player:gsub("^%s+", ""):gsub("%s+$", ""))
            end
        else
            -- Fallback parsing: 'item - player'
            local name, pl = line:match("^(.-)%s-%s(.+)$")
            if name and pl then
                byItem[name] = byItem[name] or {}
                table.insert(byItem[name], pl:gsub("^%s+", ""):gsub("%s+$", ""))
            end
        end
    end

    -- Merge parsed data into the global table
    for k, v in pairs(byItem) do
        GL.SoftResTable[k] = v
    end

    return byItem
end

-- Retrieve SR data for itemID or item name
function SR.GetSRForItemId(idOrName)
    if not GL.SoftResTable then return nil end
    return GL.SoftResTable[tostring(idOrName)] or GL.SoftResTable[idOrName]
end
