-- Core/Loot.lua
local AddonName, GL = ...
GL.Loot = GL.Loot or {}

-- Internal function to add an item to our list
local function AddItem(id, link, source)
    GL.Items = GL.Items or {}

    local entry = {
        id = tonumber(id),
        link = link,
        addedBy = source or "loot",
        time = time(),
        rolls = {},
        tradeRemaining = nil,
    }

    table.insert(GL.Items, 1, entry)

    if GL.RefreshUI then GL.RefreshUI() end
    return entry
end

-- Called when an item is shift-clicked into our addon
function GL.OnShiftClickItem(link)
    if not link then return end
    local id = link:match("|Hitem:(%d+):")
    if not id then id = link end
    AddItem(id, link, "manual")
end

-- Called by Events.lua when loot is detected
function GL.OnLootReceived(link)
    if not link then return end
    local id = link:match("|Hitem:(%d+):")
    if not id then id = link end
    AddItem(id, link, "loot")
end

-- Optional: update trade timers (placeholder)
function GL.UpdateTradeTimers()
    -- Iterate GL.Items and call TradeTimer.UpdateTradeForEntry for each
    if not GL.TradeTimer then return end
    for _, entry in ipairs(GL.Items) do
        if entry.link and not entry.tradeRemaining then
            GL.TradeTimer.UpdateTradeForEntry(entry)
        end
    end
end