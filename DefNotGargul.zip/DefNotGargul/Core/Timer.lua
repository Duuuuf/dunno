-- Core/Timer.lua
local AddonName, GL = ...
GL.Timer = GL.Timer or {}
local Timer = GL.Timer

-- Create a simple countdown timer
function Timer.Start(duration, callback)
    local t = duration or 5
    C_Timer.After(t, function()
        if callback then callback() end
    end)
end

-- Placeholder for per-item trade timer updates
function Timer.UpdateTradeForEntry(entry)
    if not entry or not entry.time then return end
    local TRADE_LIMIT = 2 * 60 * 60 -- 2 hours in seconds
    local elapsed = time() - entry.time
    entry.tradeRemaining = math.max(TRADE_LIMIT - elapsed, 0)
end