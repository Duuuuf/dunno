-- Core/TradeTimer.lua
local AddonName, GL = ...
GL.TradeTimer = GL.TradeTimer or {}
local TT = GL.TradeTimer

-- Update tradeRemaining for a specific entry
function TT.UpdateTradeForEntry(entry)
    if not entry or not entry.time then return end
    local TRADE_LIMIT = 2 * 60 * 60 -- 2 hours in seconds
    local elapsed = time() - entry.time
    entry.tradeRemaining = math.max(TRADE_LIMIT - elapsed, 0)
end

-- Periodically update all items
function TT.UpdateAll()
    if not GL.Items then return end
    for _, entry in ipairs(GL.Items) do
        TT.UpdateTradeForEntry(entry)
    end
    if GL.RefreshUI then GL.RefreshUI() end
end